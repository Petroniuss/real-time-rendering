#include "material.h"

Material::Material()
{

}


﻿Materiały i ich przekazanie do fragment shadera.

Demonstruje:
1. jak zdefiniować materiał
2. jak przekazać materiał do shadera

Zadanie:
1. Poeksperymentować z parametrami, aby uzyskać wrażenie różnych materiałów. Jakie są ograniczenia cieniowania Phonga?

(http://devernay.free.fr/cours/opengl/materials.html)
﻿Punktowe źródło światła.

Demonstruje:
1. jak obliczyć kolor wg modelu Phonga
2. że można przekazać wektor do fragment shadera

Zadanie:
1. zmienić kolor smoków na czerwony
